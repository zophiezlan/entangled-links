# Entangled Links 🔗⚛️

A genuinely novel URL shortener where links are cryptographically entangled. Accessing one link observably affects its paired twin.

## 🎯 The Innovation

Unlike traditional URL shorteners, Entangled Links creates **paired short URLs** that are cryptographically bound together:

- **Superposition**: Links start in an undefined state
- **Collapse**: First access determines the configuration
- **Observable**: Each link shows if its twin has been accessed
- **Mutual Decryption**: Both links needed to reveal final destination

## 🏗️ Architecture

### Tech Stack
- **Runtime**: Cloudflare Workers (edge computing, global deployment)
- **Storage**: Cloudflare KV (distributed key-value store)
- **Crypto**: Web Crypto API (native cryptographic operations)
- **Frontend**: Vanilla JS + Modern CSS (no frameworks, fast loading)

### Core Components

1. **Link Generator** (`/generate`)
   - Creates entangled pair
   - Splits encryption keys
   - Stores entanglement state

2. **Link Resolver** (`/:shortcode`)
   - Checks entanglement state
   - Updates twin status
   - Decrypts and redirects

3. **State Viewer** (`/:shortcode/status`)
   - Shows entanglement metadata
   - Displays twin state
   - Privacy-respecting analytics

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- Wrangler CLI (`npm install -g wrangler`)
- Cloudflare account (free tier works)

### Development

```bash
# Install dependencies
npm install

# Start local dev server
npm run dev

# Deploy to Cloudflare
npm run deploy
```

## 🔐 Cryptographic Design

### Entanglement States
- `SUPERPOSITION` - Neither link accessed
- `COLLAPSED_A` - Link A accessed first
- `COLLAPSED_B` - Link B accessed first
- `OBSERVED` - Both links accessed

### Key Splitting
- Original URL encrypted with master key
- Master key split into Key A + Key B
- Each short link contains one half
- XOR-based key reconstruction

## 🎨 Use Cases

- **Secure Handshakes**: Coordinate without shared channel
- **Consent Verification**: Both parties must click
- **Dead Drops**: Split sensitive information
- **ARGs/Puzzles**: Links that unlock each other
- **Trust Networks**: Provable coordination

## 📋 Roadmap

### Phase 1: Core (MVP)
- [x] Project scaffolding
- [ ] Basic link pairing
- [ ] State management
- [ ] Simple resolver
- [ ] Status page

### Phase 2: Cryptography
- [ ] Key splitting algorithm
- [ ] Mutual decryption
- [ ] State transitions
- [ ] Security hardening

### Phase 3: Experience
- [ ] Visual state indicators
- [ ] Link expiration
- [ ] Custom domains
- [ ] Analytics dashboard

### Phase 4: Advanced
- [ ] Cascade networks (3+ links)
- [ ] Conditional logic
- [ ] API for integrations
- [ ] Zero-knowledge mode

## 🛡️ Security Considerations

- No URLs stored in plaintext
- Rate limiting on generation
- CORS protection
- CSP headers
- No tracking/fingerprinting

## 📄 License

MIT - Built for creative exploration and harm reduction use cases

---

**Built with ❤️ for genuinely novel web experiences**
