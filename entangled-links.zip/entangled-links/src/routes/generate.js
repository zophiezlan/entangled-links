/**
 * Generate entangled link pair
 * POST /generate
 * Body: { url: "https://example.com" }
 */

import { generateShortcode, generateMasterKey, splitKey, encryptUrl } from '../crypto/entanglement.js';
import { createEntangledPair, storePair } from '../lib/state.js';

export async function generatePair(request, env) {
  try {
    // Parse request body
    const body = await request.json();
    const { url } = body;
    
    // Validate URL
    if (!url || !isValidUrl(url)) {
      return new Response(
        JSON.stringify({ error: 'Invalid URL provided' }),
        { 
          status: 400,
          headers: { 'Content-Type': 'application/json' }
        }
      );
    }
    
    // Generate unique shortcodes
    const shortcodeA = generateShortcode(8);
    const shortcodeB = generateShortcode(8);
    
    // Generate and split encryption key
    const masterKey = await generateMasterKey();
    const { keyA, keyB } = await splitKey(masterKey);
    
    // Encrypt the URL
    const encryptedData = await encryptUrl(url, masterKey);
    
    // Create entangled pair
    const pairData = createEntangledPair(
      shortcodeA,
      shortcodeB,
      encryptedData,
      keyA,
      keyB
    );
    
    // Store in KV
    await storePair(env, pairData);
    
    // Get base URL from request
    const baseUrl = new URL(request.url).origin;
    
    // Return the entangled pair
    return new Response(
      JSON.stringify({
        success: true,
        pair: {
          id: pairData.pairId,
          linkA: `${baseUrl}/${shortcodeA}`,
          linkB: `${baseUrl}/${shortcodeB}`,
          statusA: `${baseUrl}/${shortcodeA}/status`,
          statusB: `${baseUrl}/${shortcodeB}/status`,
          state: pairData.state,
          expiresAt: pairData.expiresAt
        }
      }),
      {
        status: 201,
        headers: { 
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
      }
    );
    
  } catch (error) {
    console.error('Generate pair error:', error);
    return new Response(
      JSON.stringify({ error: 'Failed to generate entangled pair' }),
      { 
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      }
    );
  }
}

function isValidUrl(string) {
  try {
    const url = new URL(string);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch (_) {
    return false;
  }
}
