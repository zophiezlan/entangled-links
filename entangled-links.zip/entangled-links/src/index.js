/**
 * Entangled Links - Main Worker Entry Point
 * 
 * Routes:
 * - GET  /                    -> Landing page
 * - POST /generate            -> Create entangled pair
 * - GET  /:shortcode          -> Resolve and redirect
 * - GET  /:shortcode/status   -> View entanglement state
 */

import { Router } from './lib/router.js';
import { generatePair } from './routes/generate.js';
import { resolveLink } from './routes/resolve.js';
import { viewStatus } from './routes/status.js';
import { landingPage } from './ui/landing.js';

export default {
  async fetch(request, env, ctx) {
    const router = new Router();

    // Landing page
    router.get('/', () => landingPage());

    // Generate entangled pair
    router.post('/generate', (req) => generatePair(req, env));

    // View status
    router.get('/:shortcode/status', (req, params) => 
      viewStatus(params.shortcode, env)
    );

    // Resolve link (must be last - catch-all)
    router.get('/:shortcode', (req, params) => 
      resolveLink(params.shortcode, env, ctx)
    );

    // Handle request
    try {
      return await router.handle(request);
    } catch (error) {
      console.error('Worker error:', error);
      return new Response('Internal Server Error', { 
        status: 500,
        headers: { 'Content-Type': 'text/plain' }
      });
    }
  }
};
